
  # Interactive Eye-Following Card (Community)

  This is a code bundle for Interactive Eye-Following Card (Community). The original project is available at https://www.figma.com/design/ahY0Zd0JUMc4zGk4q3UIja/Interactive-Eye-Following-Card--Community-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  